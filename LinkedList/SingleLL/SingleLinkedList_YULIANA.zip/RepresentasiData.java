package LinkedList.SingleLL;

/**
 * @author YoulMin01
 */

public class RepresentasiData {
    String nama;
    int harga;
    RepresentasiData(String n, int h) {
        nama = n;
        harga = h;

    }
    public String getNama() {
        return nama;
    }
}
