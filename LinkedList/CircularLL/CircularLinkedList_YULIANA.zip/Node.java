package LinkedList.CircularLL;

/**
 *
 * @author YoulMin01
 */

public class Node {
        double data;
        Node next;
        public Node(double data) {
            this.data = data;
        }
}
