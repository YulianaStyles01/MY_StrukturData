package LinkedList.MultipleLL;

/**
 * @author YoulMin01
 */

public class NodeMultiple {
    public NodeMultiple next;
    public String data;
    public Object down;

    public static class Node{
        String data;
        Node next;
        Node down;
    }
}
